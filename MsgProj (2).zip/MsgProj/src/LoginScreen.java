
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class LoginScreen extends javax.swing.JDialog {
    protected String Host = "216.159.71.254";
    
    public LoginScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EmailLFld = new javax.swing.JTextField();
        PasswordLFld = new javax.swing.JPasswordField();
        LoginLBtn = new javax.swing.JButton();
        RegiLBtn = new javax.swing.JButton();
        EnterEMPWLbl = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        EmailLFld.setText("Enter Username");

        PasswordLFld.setText("jPasswordField1");

        LoginLBtn.setText("Login");
        LoginLBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                LoginLBtnActionPerformed(evt);
            }
        });

        RegiLBtn.setText("Register?");

        EnterEMPWLbl.setText("Enter Your Email and Password");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(139, 139, 139)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(RegiLBtn, javax.swing.GroupLayout.DEFAULT_SIZE, 103, Short.MAX_VALUE)
                            .addComponent(LoginLBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(122, 122, 122)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(PasswordLFld)
                            .addComponent(EmailLFld))))
                .addContainerGap(123, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 94, Short.MAX_VALUE)
                .addComponent(EnterEMPWLbl)
                .addGap(89, 89, 89))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(100, Short.MAX_VALUE)
                .addComponent(EnterEMPWLbl)
                .addGap(18, 18, 18)
                .addComponent(EmailLFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(PasswordLFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(LoginLBtn)
                .addGap(18, 18, 18)
                .addComponent(RegiLBtn)
                .addGap(37, 37, 37))
        );

        EmailLFld.getAccessibleContext().setAccessibleName("");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void LoginLBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_LoginLBtnActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                out.println("LOGIN");
                out.println(EmailLFld.getText());
                out.println(PasswordLFld.getPassword());
                System.out.println("Info Transfered");
                String com = in.nextLine();
                if(com.startsWith("DNE")){
                    EnterEMPWLbl.setText("User Does Not Exist");
                }else if(com.startsWith("BADPASS")){
                    EnterEMPWLbl.setText("Incorrect Password");
                }else if(com.startsWith("LOGGED")){
                    EnterEMPWLbl.setText("Login Complete");
                    HomeFrame Home = new HomeFrame();
                    Home.User = in.nextLine();
                    Home.setVisible(true);
                    this.dispose();
                }else{
                    EnterEMPWLbl.setText("Unknown Error");
                }
                
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_LoginLBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LoginScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LoginScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LoginScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LoginScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                LoginScreen dialog = new LoginScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField EmailLFld;
    private javax.swing.JLabel EnterEMPWLbl;
    private javax.swing.JButton LoginLBtn;
    private javax.swing.JPasswordField PasswordLFld;
    private javax.swing.JButton RegiLBtn;
    // End of variables declaration//GEN-END:variables
}
