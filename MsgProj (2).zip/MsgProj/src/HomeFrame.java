
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;
import java.util.ArrayList;
import javax.swing.BoxLayout;

public class HomeFrame extends javax.swing.JFrame {
    protected String User;
    protected ArrayList<String> following;
    protected int followingCount;
    protected ArrayList<String> sentLog = new ArrayList<>();
    protected String Host = "216.159.71.254";
    public HomeFrame() {
        initComponents();
        scrollPan.setLayout(new BoxLayout(scrollPan,BoxLayout.Y_AXIS));
        searchPan.setLayout(new BoxLayout(searchPan,BoxLayout.Y_AXIS));
        
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jToolBar1 = new javax.swing.JToolBar();
        msgSearchBar = new javax.swing.JTextField();
        resultsBar = new javax.swing.JScrollPane();
        searchPan = new javax.swing.JPanel();
        testFollowBtn = new javax.swing.JButton();
        logoutBtn = new javax.swing.JButton();
        followCheckBtn = new javax.swing.JButton();
        msgFld = new javax.swing.JTextField();
        sendMsgBtn = new javax.swing.JButton();
        userSearchBar = new javax.swing.JTextField();
        shutDownBtn = new javax.swing.JButton();
        msgSearchBtn = new javax.swing.JButton();
        userSearchBtn = new javax.swing.JButton();
        hashFld = new javax.swing.JTextField();
        hashLbl = new javax.swing.JLabel();
        msgLbl = new javax.swing.JLabel();
        serverLbl = new javax.swing.JLabel();
        serverMsgLbl = new javax.swing.JLabel();
        msgPaneTb = new javax.swing.JTabbedPane();
        sentLbl = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        receivedLbl = new javax.swing.JLabel();
        checkMsgBtn = new javax.swing.JButton();
        msgSearchLbl = new javax.swing.JLabel();
        bigScrollPan = new javax.swing.JScrollPane();
        scrollPan = new javax.swing.JPanel();

        jToolBar1.setRollover(true);

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        msgSearchBar.setText("Search Msgs");

        javax.swing.GroupLayout searchPanLayout = new javax.swing.GroupLayout(searchPan);
        searchPan.setLayout(searchPanLayout);
        searchPanLayout.setHorizontalGroup(
            searchPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 168, Short.MAX_VALUE)
        );
        searchPanLayout.setVerticalGroup(
            searchPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 158, Short.MAX_VALUE)
        );

        resultsBar.setViewportView(searchPan);

        testFollowBtn.setText("Test Follow");
        testFollowBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                testFollow(evt);
            }
        });

        logoutBtn.setText("Logout");
        logoutBtn.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        logoutBtn.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        logoutBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logOutAction(evt);
            }
        });

        followCheckBtn.setText("Check Follows");
        followCheckBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                followCheckBtnActionPerformed(evt);
            }
        });

        sendMsgBtn.setText("Send");
        sendMsgBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendMsgBtnActionPerformed(evt);
            }
        });

        userSearchBar.setText("Search Users");

        shutDownBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                shutDownBtnActionPerformed(evt);
            }
        });

        msgSearchBtn.setText("Search");
        msgSearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msgSearchBtnActionPerformed(evt);
            }
        });

        userSearchBtn.setText("Search");
        userSearchBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                userSearchBtnActionPerformed(evt);
            }
        });

        hashLbl.setText("Enter Hashtag");

        msgLbl.setText("Enter Message");

        serverLbl.setText("Server Messages:");

        serverMsgLbl.setText("NA");

        msgPaneTb.addTab("Sent", sentLbl);

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(receivedLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 404, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(receivedLbl, javax.swing.GroupLayout.DEFAULT_SIZE, 241, Short.MAX_VALUE))
        );

        msgPaneTb.addTab("Received", jPanel1);

        checkMsgBtn.setText("Check Messages");
        checkMsgBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                checkMsgBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout scrollPanLayout = new javax.swing.GroupLayout(scrollPan);
        scrollPan.setLayout(scrollPanLayout);
        scrollPanLayout.setHorizontalGroup(
            scrollPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 144, Short.MAX_VALUE)
        );
        scrollPanLayout.setVerticalGroup(
            scrollPanLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 646, Short.MAX_VALUE)
        );

        bigScrollPan.setViewportView(scrollPan);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bigScrollPan, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(msgSearchLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(234, 234, 234)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(hashLbl)
                            .addComponent(hashFld, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(msgLbl)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(msgFld, javax.swing.GroupLayout.PREFERRED_SIZE, 421, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(sendMsgBtn)))
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(msgSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(msgSearchBtn))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(checkMsgBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(followCheckBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(msgPaneTb, javax.swing.GroupLayout.PREFERRED_SIZE, 416, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(157, 157, 157)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(serverLbl)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(serverMsgLbl)
                                        .addGap(0, 0, Short.MAX_VALUE))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addGap(0, 0, Short.MAX_VALUE)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(testFollowBtn)
                                            .addComponent(logoutBtn))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(shutDownBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(resultsBar, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(userSearchBtn)
                                .addContainerGap())))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(logoutBtn)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(serverLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(serverMsgLbl))))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(287, 287, 287)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(msgSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(msgSearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(msgLbl)
                            .addComponent(hashLbl, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(75, 75, 75))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(21, 21, 21)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(userSearchBar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(userSearchBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
            .addGroup(layout.createSequentialGroup()
                .addGap(76, 76, 76)
                .addComponent(resultsBar, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(shutDownBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(233, 233, 233)
                .addComponent(testFollowBtn)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(sendMsgBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(hashFld, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(msgFld, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(msgSearchLbl, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 195, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(layout.createSequentialGroup()
                .addComponent(followCheckBtn)
                .addGap(4, 4, 4)
                .addComponent(msgPaneTb, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(checkMsgBtn)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(bigScrollPan)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private void createUser(String userName) {                             
       newUser user = new newUser(userName,scrollPan,User);
       System.out.println("Adding a panel");
       scrollPan.add(user);
       scrollPan.revalidate();
       scrollPan.repaint();
       //testArea.append(userName);
       System.out.println("Test Successful");
    }
    private void createSearch(String userName) {                             
       searchUsers user = new searchUsers(userName,searchPan,User);
       System.out.println("Adding a panel");
       searchPan.add(user);
       searchPan.revalidate();
       searchPan.repaint();
       System.out.println("Adding a panel");
    }
    private void testFollow(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_testFollow
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("Socket Made");
                out.println("FOLLOW");
                out.println(User);
                out.println("Justin");
                //String com = in.nextLine();
                /*
                if(com.startsWith("FOLLOWED")){
                    createUser("Test");
                    System.out.println("Test Successful");
                }
                */
                System.out.println("Followed");
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_testFollow

    private void logOutAction(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logOutAction
        try {
            Socket s = new Socket(Host, 2008);

            PrintWriter out = new PrintWriter(s.getOutputStream(), true);

            Scanner in = new Scanner(s.getInputStream());
            System.out.println("Socket Made");
            out.println("LOGOUT");
            out.println(User);
            String com = in.nextLine();
            if(com.startsWith("EXIT")){
                LoginScreen Log = new LoginScreen(null,false);
                Log.setVisible(true);
                this.dispose();
            }

            out.close();
            s.close();

        } catch(IOException e) {
            System.err.println(e.getMessage());
        }
    }//GEN-LAST:event_logOutAction

    private void followCheckBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_followCheckBtnActionPerformed
            try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("Socket Made");
                out.println("FOLLOWCHECK");
                out.println(User);
                String com = in.nextLine();
                if(com.startsWith("NOFOLLOW")){
                    serverMsgLbl.setText("Not Following Anyone");
                    out.close();
                    s.close();
                }else{
                    following = new ArrayList<>();
                    followingCount = Integer.parseInt(com);
                    for(int i = 0; i < followingCount; i++){
                        com= in.nextLine();
                        following.add(com);
                    }
                    for(int i = 0; i < followingCount; i++){
                        createUser(following.get(i));
                    }
                }
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_followCheckBtnActionPerformed

    private void sendMsgBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendMsgBtnActionPerformed
        sentLog.add(msgFld.getText());
        sentLbl.setText(sentLbl.getText() + "\n" + msgFld.getText());
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                //Scanner in = new Scanner(s.getInputStream());
                System.out.println("Socket Made");
                if(!hashFld.getText().isEmpty()){
                    if(!msgFld.getText().isEmpty()){
                        out.println("SENDMSG");
                        out.println(hashFld.getText());
                        out.println("Message From " + User + ": " +"#"+ hashFld.getText() + " " + msgFld.getText());
                        out.println(User);
                    }else{
                        serverMsgLbl.setText("Please Enter Message");
                    }
                }else{
                    serverMsgLbl.setText("Please Enter Hashtag");
                }
                

		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_sendMsgBtnActionPerformed

    private void shutDownBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_shutDownBtnActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                //Scanner in = new Scanner(s.getInputStream());
                System.out.println("Socket Made");
                out.println("KILL");

		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_shutDownBtnActionPerformed

    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        try {
            Socket s = new Socket(Host, 2008);

            PrintWriter out = new PrintWriter(s.getOutputStream(), true);

            //Scanner in = new Scanner(s.getInputStream());
            System.out.println("Socket Made");
            out.println("LOGOUT");
            out.println(User);
           
            out.close();
            s.close();

        } catch(IOException e) {
            System.err.println(e.getMessage());
        }
        System.exit(0);
    }//GEN-LAST:event_formWindowClosing

    private void msgSearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msgSearchBtnActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);
                
                Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                out.println("SEARCHMSG");
                out.println(msgSearchBar.getText());
                String com=in.nextLine();
                
                if(com.startsWith("DNE")){
                    serverMsgLbl.setText("No Messages Found");
                }else{
                    msgSearchLbl.setText(com);
                }

		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_msgSearchBtnActionPerformed

    private void userSearchBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_userSearchBtnActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                if(!userSearchBar.getText().isEmpty()){
                    out.println("SEARCHUSER");
                    out.println(User);
                    out.println(userSearchBar.getText());
                    String com = in.nextLine();
                    if(com.startsWith("DNE")){
                        serverMsgLbl.setText("User Doesn't Exist");
                    }else if(!com.startsWith("ALRFOLLOWED")){ 
                        createSearch(com);
                        //serverMsgLbl.setText("User Followed");
                    }
                }else{
                    serverMsgLbl.setText("Please Enter User");
                }

		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_userSearchBtnActionPerformed

    private void checkMsgBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_checkMsgBtnActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                int msgCount=0;
                System.out.println("SOcket Made");
                out.println("MSGCHECK");
                out.println(User);
                String com=in.nextLine();
                if(!com.startsWith("NOMSG")){
                    msgCount=Integer.parseInt(com);
                    for(int i=0;i<msgCount;i++){
                        com=in.nextLine();
                        receivedLbl.setText(receivedLbl.getText() + "\n" + com);
                    }
                    
                }else if(com.startsWith("NOMSG")){
                    serverMsgLbl.setText("No New Messages");
                }
                
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_checkMsgBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
       System.out.println("Test Successful");
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HomeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HomeFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane bigScrollPan;
    private javax.swing.JButton checkMsgBtn;
    private javax.swing.JButton followCheckBtn;
    private javax.swing.JTextField hashFld;
    private javax.swing.JLabel hashLbl;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JToolBar jToolBar1;
    private javax.swing.JButton logoutBtn;
    private javax.swing.JTextField msgFld;
    private javax.swing.JLabel msgLbl;
    private javax.swing.JTabbedPane msgPaneTb;
    private javax.swing.JTextField msgSearchBar;
    private javax.swing.JButton msgSearchBtn;
    private javax.swing.JLabel msgSearchLbl;
    private javax.swing.JLabel receivedLbl;
    private javax.swing.JScrollPane resultsBar;
    private javax.swing.JPanel scrollPan;
    private javax.swing.JPanel searchPan;
    private javax.swing.JButton sendMsgBtn;
    private javax.swing.JLabel sentLbl;
    private javax.swing.JLabel serverLbl;
    private javax.swing.JLabel serverMsgLbl;
    private javax.swing.JButton shutDownBtn;
    private javax.swing.JButton testFollowBtn;
    private javax.swing.JTextField userSearchBar;
    private javax.swing.JButton userSearchBtn;
    // End of variables declaration//GEN-END:variables
}
