
import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;


public class RegisterScreen extends javax.swing.JDialog {
    protected String Host = "216.159.71.254";

    public RegisterScreen(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        EmailRFld = new javax.swing.JTextField();
        PasswordRFld = new javax.swing.JPasswordField();
        RegiRButt = new javax.swing.JButton();
        LoginRFld = new javax.swing.JButton();
        serverMsgLbl = new javax.swing.JLabel();
        testReg = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        EmailRFld.setText("Enter Username");

        PasswordRFld.setText("jPasswordField1");

        RegiRButt.setText("Register");
        RegiRButt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegiRButtActionPerformed(evt);
            }
        });

        LoginRFld.setText("Login?");

        serverMsgLbl.setText("Server Msgs:");

        testReg.setText("Dummy Register");
        testReg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                testRegActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(testReg)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(146, 146, 146)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addComponent(RegiRButt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(LoginRFld, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(126, 126, 126)
                                    .addComponent(PasswordRFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(29, 29, 29))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(EmailRFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(serverMsgLbl, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(110, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(serverMsgLbl)
                .addGap(18, 18, 18)
                .addComponent(EmailRFld, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(PasswordRFld, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(RegiRButt)
                .addGap(18, 18, 18)
                .addComponent(LoginRFld)
                .addGap(18, 18, 18)
                .addComponent(testReg)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RegiRButtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegiRButtActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                out.println("REG");
                out.println(EmailRFld.getText());
                out.println(PasswordRFld.getPassword());
                System.out.println("Info Transfered");
                String com = in.nextLine();
                if(com.startsWith("LOGS")){
                    serverMsgLbl.setText("Registration Complete");
                    LoginScreen Log = new LoginScreen(null,false);
                    Log.setVisible(true);
                    this.dispose();
                }else if(com.startsWith("EXISTS")){
                    serverMsgLbl.setText("User Name Taken");
                }else{
                    serverMsgLbl.setText("Unknown Error");
                }
                
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_RegiRButtActionPerformed

    private void testRegActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_testRegActionPerformed
        try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                out.println("TREG");
                out.println("Emily");
                out.println("1");
                System.out.println("Emily created");
                out.println("Tristan");
                out.println("1");
                System.out.println("Tristan created");
                out.println("Justin");
                out.println("1");
                System.out.println("Justin created");
                out.println("Adam");
                out.println("1");
                System.out.println("Adam created");
                
                
		out.close();
		s.close();
	    

	} catch(IOException e) {
	    System.err.println(e.getMessage());
	}
    }//GEN-LAST:event_testRegActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(RegisterScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(RegisterScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(RegisterScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(RegisterScreen.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                RegisterScreen dialog = new RegisterScreen(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField EmailRFld;
    private javax.swing.JButton LoginRFld;
    private javax.swing.JPasswordField PasswordRFld;
    private javax.swing.JButton RegiRButt;
    private javax.swing.JLabel serverMsgLbl;
    private javax.swing.JButton testReg;
    // End of variables declaration//GEN-END:variables
}
