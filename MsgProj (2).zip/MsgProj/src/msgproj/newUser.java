
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class newUser extends javax.swing.JPanel {
    JPanel parent;
    String user;
    protected String Host = "216.159.71.254";
    
    public newUser(String userTxt, JPanel bigPane, String User) {
        initComponents();
        panelLabel.setText(userTxt);
        parent = bigPane;
        user = User;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        panelLabel = new javax.swing.JLabel();
        unfollowBtn = new javax.swing.JButton();

        panelLabel.setText("a Label");

        unfollowBtn.setText("Unfollow");
        unfollowBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                unfollowBtnremoveHandler(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(panelLabel)
                .addGap(18, 18, 18)
                .addComponent(unfollowBtn))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(panelLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(unfollowBtn))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void unfollowBtnremoveHandler(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_unfollowBtnremoveHandler
        if (parent != null) {
            try {
	    Socket s = new Socket(Host, 2008);

		PrintWriter out = new PrintWriter(s.getOutputStream(), true);

                //Scanner in = new Scanner(s.getInputStream());
                System.out.println("SOcket Made");
                //String com = in.nextLine();
                out.println("UNFOLLOW");
                out.println(user);
                out.println(panelLabel.getText());
                parent.remove(this);
                parent.revalidate();
		out.close();
		s.close();
	    

            }catch(IOException e) {
                System.err.println(e.getMessage());
                }
        }else{
            JOptionPane.showMessageDialog(this,"Panel is null");
        }
    }//GEN-LAST:event_unfollowBtnremoveHandler


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel panelLabel;
    private javax.swing.JButton unfollowBtn;
    // End of variables declaration//GEN-END:variables
}
